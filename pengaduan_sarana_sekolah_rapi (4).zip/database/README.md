# Database

Aplikasi ini **tidak menggunakan database SQL (MySQL/PostgreSQL/dsb)**.
Database yang dipakai adalah **Cloud Firestore** (NoSQL, milik Firebase), sehingga
tidak ada file `database.sql`. Sebagai gantinya, struktur data (koleksi/collection)
didokumentasikan di file ini agar tetap memenuhi ketentuan "database harus dapat
ditemukan dengan jelas di repository".

> Catatan: untuk paket soal **P1** yang secara eksplisit meminta relasi antar tabel,
> stored procedure, function, trigger, serta commit/rollback (fitur khas SQL),
> Firestore tidak memiliki fitur tersebut. Jika paket soal yang dikerjakan adalah
> P1, sesuaikan/tambahkan implementasi database relasional sesuai ketentuan soal,
> atau konfirmasikan ke pembimbing/asesor terkait penggunaan Firestore ini.

## Koleksi (Collection)

### 1. `pengaduan`
Menyimpan data pengaduan sarana sekolah yang dibuat siswa.

| Field       | Tipe        | Keterangan                                   |
|-------------|-------------|-----------------------------------------------|
| id          | string      | Document ID (auto generated oleh Firestore)   |
| userId      | string      | UID siswa/pelapor (dari Firebase Auth)        |
| nama        | string      | Nama pelapor                                  |
| kategori    | string      | Kategori sarana yang diadukan                 |
| judul       | string      | Judul pengaduan                               |
| deskripsi   | string      | Isi/detail pengaduan                          |
| status      | string      | Status pengaduan (mis. Diproses/Selesai)      |
| feedback    | string      | Tanggapan/feedback dari admin/petugas         |
| fotoUrl     | string      | URL foto bukti (disimpan di Firebase Storage) |
| tanggal     | timestamp   | Tanggal pengaduan dibuat                      |

Diakses melalui `FirestoreService` (`lib/services/firestore_service.dart`):
- `getComplaints()` → seluruh pengaduan (dipakai di sisi **admin**)
- `getMyComplaints()` → pengaduan milik siswa yang sedang login (dipakai di sisi **siswa**)

### 2. `notifications`
Menyimpan notifikasi yang dikirim ke pengguna (dikelola oleh `NotificationService`
di `lib/services/notification_service.dart`).

| Field   | Tipe      | Keterangan                     |
|---------|-----------|---------------------------------|
| id      | string    | Document ID                     |
| ...     | ...       | Lihat `notification_service.dart` untuk field lengkap |

## Autentikasi
Login/registrasi akun **siswa** menggunakan **Firebase Authentication** (email/password),
bukan tabel `users` tersendiri — data profil tambahan (jika ada) disimpan berelasi
dengan `uid` dari Firebase Auth.

Login **admin/petugas** menggunakan kombinasi Firebase Authentication **plus** sandi
akses tambahan yang didefinisikan di kode (`lib/pages/admin/admin_petugas_login_page.dart`).

⚠️ **Penting:** sandi akses admin saat ini masih ditulis langsung di source code
(hardcoded). Karena repository harus bersifat publik, sebaiknya pindahkan nilai ini
ke luar source code (misalnya Firebase Remote Config atau environment variable yang
di-gitignore) sebelum repository dipublikasikan, sesuai ketentuan pada dokumen
"Teknis Pengumpulan UKK RPL" poin 6 (kredensial rahasia tidak boleh ter-upload).

## Konfigurasi Firebase
File konfigurasi Firebase (`lib/services/firebase_options.dart` dan
`android/app/google-services.json`) tetap disertakan agar aplikasi dapat dijalankan
asesor. Pastikan **Firestore Security Rules** pada project Firebase sudah diatur
dengan benar sehingga data tidak dapat diakses/diubah sembarang orang meskipun
repository bersifat publik.
