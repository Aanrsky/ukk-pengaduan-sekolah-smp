Nama Peserta: ...
Kelas: ...
Judul Project: Aplikasi Pengaduan Sarana Sekolah
Studi Kasus: Pengaduan kerusakan/masalah sarana & prasarana di SMP Negeri 3 Bantul, dengan dua peran pengguna (Siswa & Admin/Petugas)

Teknologi:
- Frontend: Flutter (Android, iOS, Web)
- Backend: Firebase (Firebase Auth, Cloud Firestore, Firebase Storage, Firebase Cloud Messaging)
- Database: Cloud Firestore (NoSQL) — lihat detail di `database/README.md`

Fitur:
- Login & registrasi siswa (Firebase Authentication)
- Login admin/petugas dengan sandi akses tambahan
- Siswa membuat pengaduan sarana sekolah (judul, kategori, deskripsi, foto)
- Siswa melihat riwayat & status pengaduan miliknya
- Admin/petugas melihat seluruh pengaduan masuk
- Admin/petugas memberikan feedback/menindaklanjuti pengaduan
- Cetak laporan pengaduan ke PDF (admin)
- Notifikasi (Firebase Cloud Messaging + local notification)
- ...

Cara Menjalankan:
1. Pastikan Flutter SDK sudah terpasang (`flutter --version`).
2. Jalankan `flutter pub get` di root project untuk mengunduh dependency.
3. Pastikan file konfigurasi Firebase (`lib/services/firebase_options.dart`,
   `android/app/google-services.json`) sudah sesuai dengan project Firebase yang aktif,
   lalu jalankan `flutter run` (pilih device Android/iOS/Chrome).

Database:
database/README.md

Dokumentasi:
docs/

Demo:
...

Akun Pengujian:

Siswa
Username: (daftar akun baru melalui halaman Register, atau isi akun demo di sini)
Password: ...

Admin / Petugas
Username: ...
Password: ...
Sandi Akses Halaman Admin: (lihat catatan keamanan di database/README.md — sandi akses saat ini masih tertulis di source code dan sebaiknya dipindahkan sebelum repository dipublikasikan)

Known Issues:
- Beberapa file di `lib/pages/siswa/` (`home_page.dart`, `complaint_form_page.dart`) dan
  `lib/pages/admin/dashboard_page.dart` tampaknya merupakan halaman versi lama yang
  sudah tidak dipakai lagi di alur aplikasi (tidak dipanggil dari halaman manapun).
  Periksa kembali, hapus jika memang tidak diperlukan agar repository lebih rapi.
- Sandi akses admin (`accessPassword`) masih hardcoded di
  `lib/pages/admin/admin_petugas_login_page.dart`.
- ...

---

## Struktur Repository

Struktur folder mengikuti struktur bawaan Flutter (tidak dipindah ke folder `src/`,
sesuai ketentuan bahwa struktur boleh mengikuti framework yang digunakan), dengan
folder `admin` dan `siswa` dipisah di dalam `lib/pages/` agar mudah diidentifikasi
oleh asesor:

```
.
├── README.md
├── pubspec.yaml
├── database/
│   └── README.md              # dokumentasi struktur database (Firestore)
├── docs/
│   ├── README.md              # checklist dokumentasi UKK yang wajib dilengkapi
│   ├── 01-analisis-kebutuhan.pdf   (dilengkapi peserta)
│   ├── 02-perancangan.pdf          (dilengkapi peserta)
│   ├── 03-dokumentasi-program.pdf  (dilengkapi peserta)
│   ├── 04-pengujian.pdf            (dilengkapi peserta)
│   ├── 05-debugging.pdf            (dilengkapi peserta)
│   ├── 06-evaluasi.pdf             (dilengkapi peserta)
│   └── screenshots/
├── lib/
│   ├── main.dart
│   ├── pages/
│   │   ├── splash_page.dart       # shared
│   │   ├── login_page.dart        # shared (pintu masuk ke sisi admin & siswa)
│   │   ├── models/
│   │   │   └── complaint_model.dart
│   │   ├── admin/                 # ====== SISI ADMIN / PETUGAS ======
│   │   │   ├── admin_petugas_login_page.dart
│   │   │   ├── admin_petugas_register_page.dart
│   │   │   ├── admin_dashboard_page.dart
│   │   │   └── dashboard_page.dart        (belum terpakai)
│   │   └── siswa/                 # ====== SISI SISWA ======
│   │       ├── register_page.dart
│   │       ├── student_home_page.dart
│   │       ├── pengaduan_page.dart
│   │       ├── history_page.dart
│   │       ├── complaint_detail_page.dart
│   │       ├── complaint_form_page.dart   (belum terpakai)
│   │       └── home_page.dart             (belum terpakai)
│   ├── services/
│   │   ├── firebase_options.dart
│   │   ├── firestore_service.dart
│   │   ├── notification_service.dart
│   │   └── print_report_service.dart
│   └── widgets/
│       └── copyright_watermark.dart
├── android/
├── ios/
├── web/
├── assets/
└── test/
```

Catatan pemisahan admin/siswa: `login_page.dart` dan `splash_page.dart` tetap berada
langsung di `lib/pages/` karena dipakai bersama sebelum pengguna masuk ke salah satu
peran (siswa atau admin/petugas).
