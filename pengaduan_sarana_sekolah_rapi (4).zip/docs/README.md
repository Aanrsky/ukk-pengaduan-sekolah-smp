# Dokumentasi UKK

Folder ini adalah tempat dokumentasi wajib sesuai **"Teknis Pengumpulan UKK RPL"**
bagian 4 (Dokumentasi). File-file di bawah ini **belum dibuat/diisi** karena
isinya harus berasal dari proses kerja kamu sendiri (analisis, perancangan,
pengujian, dst) — bukan sesuatu yang bisa dibuatkan otomatis.

Lengkapi dan letakkan file PDF-nya di folder ini dengan nama berikut:

- [ ] `01-analisis-kebutuhan.pdf` → analisis kebutuhan, requirement, identifikasi masalah, aktor/user
- [ ] `02-perancangan.pdf` → ERD, flowchart/diagram program, flow proses, rancangan UI
- [ ] `03-dokumentasi-program.pdf` → deskripsi aplikasi, struktur aplikasi, dokumentasi fungsi/prosedur/method, teknologi yang digunakan
- [ ] `04-pengujian.pdf` → test case, expected result, actual result, status pengujian, screenshot hasil pengujian
- [ ] `05-debugging.pdf` → permasalahan/error, penyebab, solusi/perbaikan, evidence
- [ ] `06-evaluasi.pdf` → fitur yang sudah berjalan, bug yang belum diperbaiki, rencana pengembangan berikutnya

Untuk bagian **Perancangan**, beberapa hal yang bisa kamu ambil langsung dari kode:
- **ERD/struktur data**: lihat `database/README.md` (struktur koleksi Firestore `pengaduan` & `notifications`)
- **Fitur aplikasi**: bisa dilihat dari struktur folder `lib/pages/admin/` dan `lib/pages/siswa/` di README utama

## Screenshot
Simpan tangkapan layar hasil pengujian aplikasi di folder `screenshots/`
(contoh: `login.png`, `dashboard.png`, `pengaduan.png`, dll).
